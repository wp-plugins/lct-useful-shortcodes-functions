<?php
/*
Plugin Name: LCT Useful Shortcodes & Functions
Plugin URI: http://lookclassy.com/wordpress-plugins/useful-shortcodes-functions/
Description: Shortcodes & Functions that will help make your life easier.
Version: 1.0
Text Domain: lct-useful-shortcodes-functions
Author: Look Classy Technologies
Author URI: http://lookclassy.com/
License: GPLv3 (http://opensource.org/licenses/GPL-3.0)
Copyright 2013 Look Classy Technologies  (email : info@lookclassy.com)
*/

/*
Copyright (C) 2013 Look Classy Technologies

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/


require( 'misc/functions.php' );
require( 'misc/shortcodes.php' );
