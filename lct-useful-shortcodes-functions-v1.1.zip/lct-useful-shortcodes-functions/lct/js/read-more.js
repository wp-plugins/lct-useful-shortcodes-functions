function show_copy_hidden(){
	jQuery('.read-more-button').hide();
	jQuery('#read-more-hidden-copy').show('slow');
	return false;
}
