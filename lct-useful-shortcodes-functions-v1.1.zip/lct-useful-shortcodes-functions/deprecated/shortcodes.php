<?php
add_shortcode( 'up_root', 'lct_up_path' );
